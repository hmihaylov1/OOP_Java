package Task2;

public class EverythingWatcher extends NewsWatcher {

  public EverythingWatcher(NewsReporter aNewsReporter) {
    theNewsReporter = aNewsReporter;
    theNewsReporter.attach(this);
  }

  public void update() {
  System.out.println("The news watcher watching for everything");
  System.out.println("has received a new alert: ");
  System.out.println('"' + theNewsReporter.getUpdateText() + '"');
  System.out.println(" ");
  }
}
