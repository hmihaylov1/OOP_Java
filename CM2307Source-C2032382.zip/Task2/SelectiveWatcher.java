package Task2;

public class SelectiveWatcher extends NewsWatcher {

  private String categoryWatched;

  public SelectiveWatcher(NewsReporter aNewsReporter, String aCategoryToWatch) {
    theNewsReporter = aNewsReporter;
    categoryWatched = aCategoryToWatch;
    theNewsReporter.attach(this);
  }

  public void update() {
  if (categoryWatched.equals(theNewsReporter.getUpdateCategory())) {
    System.out.println("The news watcher watching for " + categoryWatched);
    System.out.println("has received a new alert: ");
    System.out.println('"' + theNewsReporter.getUpdateText() + '"');
    System.out.println(" ");
  }
  }
}
