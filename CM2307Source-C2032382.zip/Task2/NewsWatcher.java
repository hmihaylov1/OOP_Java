package Task2;

public abstract class NewsWatcher {
 protected NewsReporter theNewsReporter;

 public abstract void update();
}
