package Task5;

public class Fork {
    public boolean inUse=false;
}
