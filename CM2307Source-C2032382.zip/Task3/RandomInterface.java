package Task3;

public interface RandomInterface {
    public double next();
}
