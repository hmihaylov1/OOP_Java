package Task1;

public abstract class Pet {
  private String name;

  public abstract String classOfAnimal();

  public void setName(String petName){
    name = petName;
  }
  public String getName() {
    return name;
  }
}
