package Task1;

public class Client {
  public static void main(String[] args) {
    Chinchilla c = new Chinchilla();
    c.setName("Grumpy");
    System.out.println("The " + c.classOfAnimal() + "'s name is " + c.getName());

    ZebraFinch z = new ZebraFinch();
    z.setName("Happy");
    System.out.println("The " + z.classOfAnimal() + "'s name is " + z.getName());

    Pet p = new Chinchilla();
    p.setName("Grumpy");
    System.out.println("The " + p.classOfAnimal() + "'s name is " + p.getName());

    p = new ZebraFinch();
    p.setName("Happy");
    System.out.println("The " + p.classOfAnimal() + "'s name is " + p.getName());
  }
}
