package Task1;

public class Chinchilla extends Pet {
  public String classOfAnimal(){
    return("Chinchilla");
  }
}
