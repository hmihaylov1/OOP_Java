package Task1;

public class ZebraFinch extends Pet {
  public String classOfAnimal() {
    return ("ZebraFinch");
  }
}
